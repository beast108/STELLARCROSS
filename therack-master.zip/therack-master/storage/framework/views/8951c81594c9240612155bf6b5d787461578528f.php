<?php $__env->startSection('content'); ?>

<div class="container p-0">
  <div class="row">

    <div class="col-lg-3 col-md-3 col-sm-4 col-5 pl-4 filter">
      <div class="fixedfilter">

        <h3><i class="fa fa-filter"></i> Filter </h3>
        <input class="mt-3" type="text" id="search" placeholder="Enter product name" style="width:100%;">

        <div class="filterprice card">
          <div class="card-body">
            <h5 class="card-title">Price</h5>
            <input type="range" min="<?php echo e($minPrice); ?>" max="<?php echo e($maxPrice); ?>" value="<?php echo e($maxPrice); ?>" class="slider selector" id="pricerange">
            <p class="p-0 m-0">Max: Rp. <span id="currentrange"><?php echo e($maxPrice); ?></span></p>
          </div>
        </div>

        <div class="filtercategory card">
          <div class="card-body">
            <h5 class="card-title">Category</h5>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="checkbox" id="<?php echo e($categories['category']); ?>" class="category selector" name="category" value="<?php echo e($categories['category']); ?>" >
              <label for="<?php echo e($categories['category']); ?>"><?php echo e($categories['category']); ?></label><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>

        <div class="filterbrand card">
          <div class="card-body">
            <h5 class="card-title">Brand</h5>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="checkbox" id="<?php echo e($brands['brand']); ?>" class="brand selector" name="brand" value="<?php echo e($brands['brand']); ?>" >
              <label for="<?php echo e($brands['brand']); ?>"><?php echo e($brands['brand']); ?></label><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>

      </div>
    </div>
    <div class="col-lg-9 col-md-9 col-sm-8 col-7 pr-4">
      <h3>Product</h3>
      
      <div class="row d-flex justify-content-start" id="products">
        
      </div>

    </div>

  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\therack-master\resources\views/products/index.blade.php ENDPATH**/ ?>