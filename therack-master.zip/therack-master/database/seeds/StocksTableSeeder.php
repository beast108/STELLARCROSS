<?php

use Illuminate\Database\Seeder;

class StocksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('stocks')->insert([
            [
                'product_id'=>1,
                'name'=>"32",
                'quantity'=>0,
            ],
            [
                'product_id'=>1,
                'name'=>"33",
                'quantity'=>10,
            ],
            [
                'product_id'=>1,
                'name'=>"34",
                'quantity'=>10,
            ],
        ]);
    }
}