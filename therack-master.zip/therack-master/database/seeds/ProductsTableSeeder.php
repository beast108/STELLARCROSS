<?php

use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            [
                'id'=>1,
                'name'=>'Knalpot Norifumi A1',
                'brand'=>'NORIFUMI',
                'price'=>2000000,
                'image'=>'products/263616.jpg',
                'phonenumber'=>'082327565738',
                'category'=>'KNALPOT',
                'quantity'=>20
            ],
            [
                'id'=>2,
                'name'=>'Body Set HRV 09',
                'brand'=>'HRV',
                'price'=>1000000,
                'image'=>'products/263611.jpg',
                'phonenumber'=>'082327565738',
                'category'=>'HRV',
                'quantity'=>20
            ],
            [
                'id'=>3,
                'name'=>'Bagasi Belakang Motor',
                'brand'=>'LAINNYA',
                'price'=>200000,
                'image'=>'products/263780.jpg',
                'phonenumber'=>'082327565738',
                'category'=>'LAINNYA',
                'quantity'=>20
            ],

        ]);
    }
}