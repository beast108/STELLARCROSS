@extends('layouts.app')

@section ('content')

<div class="container p-0">
  @if(Session::has('success'))
  <div class="row">
    <div class="col-12">
      <div id="charge-message" class="alert alert-success">
        {{ Session::get('success') }}
      </div>
    </div>
  </div>
  @endif
  <!-- GET FIT FROM HOME [S]-->
    <div class="row">
      <div class="col-12 promowrap">
        <div class="row m-0 p-0">
          <div class="col-4 promo-info h-100">
            <div class="infowrapper d-flex flex-column h-100 justify-content-center">
              <h2>WELCOME to STELLARCROSS.ID</h2>
              <h4>Trail Accessories</h4>
              <p>Yogyakarta, Indonesia</p>
              <a href="{{ route('product.index') }}" class="w-100 button">LIHAT KATALOG</a>
            </div>   
          </div> 
        </div>
        <img class="d-block w-100" src="{{ asset('photo/bg.jpg') }}" alt="">
      </div>
    </div>
    <!-- GET FIT FROM HOME [E]-->

        <!-- CATEGORY [S]-->
        <h2 class="pt-4">KATEGORI</h2>
        <div class="row m-0 pt-4">
          <div class="col-lg-4 col-sm-12 d-flex flex-column align-items-center categorywrapper">
            <a href="{{ route('product.index') }}">
              <div class="category">
                <img class="" height="200px" src="{{ asset('photo/logo1.png') }}" alt="">
                <h5 class="pt-2">KNALPOT</h5>
              </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-12 d-flex flex-column align-items-center categorywrapper">
            <a href="#">
              <div class="category">
                <img class="" height="200px" src="{{ asset('photo/logo2.png') }}" alt="">
                <h5 class="pt-2">BODY SET</h5>
            </div>
            </a>
          </div>
          <div class="col-lg-4 col-sm-12 d-flex flex-column align-items-center categorywrapper">
            <a href="#">
              <div class="category">
                <img class="" height="200px" src="{{ asset('photo/logo3.png') }}" alt="">
                <h5 class="pt-2">LAINNYA</h5>
              </div>
            </a>
          </div>
        </div>
        <!-- CATEGORY [E]-->

    

@endsection